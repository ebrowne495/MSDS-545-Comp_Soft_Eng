"""Run with: streamlit run app.py"""
from pathlib import Path
import pandas as pd
import streamlit as st
from dta_utils import load_model, predict_affinity

ROOT = Path(__file__).resolve().parent
st.set_page_config(page_title='Davis Drug–Target Affinity Predictor', page_icon='🧪', layout='centered')
st.title('Drug–Target Binding Affinity Predictor')
st.write('Enter a drug SMILES and choose a Davis protein to predict binding affinity using a trained gradient-boosting model.')

@st.cache_resource
def get_model():
    return load_model(ROOT / 'davis_affinity_model.joblib')

@st.cache_data
def get_targets():
    return pd.read_csv(ROOT / 'davis_targets.csv')

try:
    model = get_model()
    targets = get_targets()
except (FileNotFoundError, OSError, ValueError) as error:
    st.error(f'Model or protein list is missing: {error}. Run all notebook cells first.')
    st.stop()

examples = pd.read_csv(ROOT / 'davis_examples.csv') if (ROOT / 'davis_examples.csv').exists() else None
sample_smiles = str(examples.iloc[0]['compound_iso_smiles']) if examples is not None else ''
with st.form('affinity_form'):
    smiles = st.text_area('Drug SMILES', value=sample_smiles, height=100, help='Paste a valid chemical SMILES string, not a drug name.')
    selected = st.selectbox('Target protein (Davis dataset)', targets['protein_label'].tolist())
    submit = st.form_submit_button('Predict binding affinity', type='primary')

if submit:
    try:
        sequence = str(targets.set_index('protein_label').loc[selected, 'target_sequence'])
        predicted = predict_affinity(smiles, sequence, model)
        st.metric('Predicted Davis affinity (pKd)', f'{predicted:.3f}')
        st.caption('Higher pKd generally indicates stronger binding. Predictions are estimates, not laboratory measurements.')
        st.info('Davis values are strongly concentrated at 5.0. Accuracy can be limited for new molecules or proteins outside the training data.')
    except (ValueError, TypeError, KeyError) as error:
        st.error(str(error))

with st.expander('What do the inputs and predictions mean?'):
    st.write('The model combines 2,048 Morgan fingerprint bits and 20 amino-acid composition values (2,068 features). The evaluation uses a held-out split of unique drug–target pairs, not a cold-drug or cold-protein benchmark.')
