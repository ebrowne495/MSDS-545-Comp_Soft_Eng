# Davis Drug–Target Binding Affinity Predictor

A class-demo implementation of the Tier 1 predictor from the project proposal. This project uses the **uploaded `davis_all.csv`**; the KIBA file is not used. No network download or PyTDC call is required. The notebook contains numbered steps with explanatory text and executable code.

## Run locally

1. Place all included files in the same folder and open a terminal there.
2. Install: `pip install -r requirements.txt` (a conda environment is also fine).
3. Open: `jupyter notebook Davis_Drug_Target_Affinity_Project.ipynb` and choose **Run All**.
4. Run checks: `python -m pytest -q test_dta_utils.py`.
5. Start the interface: `streamlit run app.py`.
6. Select a protein from the dropdown, paste a valid SMILES, and click **Predict binding affinity**.

After running the notebook, the app requires `davis_affinity_model.joblib`, `davis_targets.csv` and `davis_examples.csv` next to `app.py`. These are also included in the project ZIP.

## Demo talking points

- Davis stores SMILES, protein sequences, and experimentally derived affinity values.
- RDKit converts a drug SMILES to **2,048 Morgan bits**; amino acid composition converts a protein sequence to **20 numbers**.
- An XGBoost gradient-boosting regressor learns to predict the continuous Davis affinity (pKd) from the combined **2,068** features.
- The notebook plots data distributions and evaluates MAE, RMSE, and R² on held-out *unique drug–target pairs*; a mean-value baseline puts results in perspective.
- Because Davis contains repeated measurements and many values at **5.0**, predicted values are estimates and should not be used as experimental conclusions.
- Random pair splits can reuse drugs/proteins between train and test; cold-drug or cold-target splits would be more challenging future validation.

## Docker (optional deployment)

After running notebook: `docker build -t davis-predictor .` then `docker run -p 8501:8501 davis-predictor`.
