import numpy as np
import pytest
from dta_utils import featurize_drug, featurize_target, pair_features

def test_fingerprint_shape():
    f = featurize_drug('CCO')
    assert f.shape == (2048,) and set(np.unique(f)).issubset({0., 1.})

def test_amino_acid_composition():
    f = featurize_target('ACDE')
    assert f.shape == (20,) and np.isclose(f.sum(), 1.0)

def test_pair_shape():
    assert pair_features('CCO', 'ACDE').shape == (2068,)

@pytest.mark.parametrize('bad_smiles', ['', 'this is not SMILES', None])
def test_bad_smiles(bad_smiles):
    with pytest.raises(ValueError):
        featurize_drug(bad_smiles)

@pytest.mark.parametrize('bad_sequence', ['', 'ACX', None])
def test_bad_sequences(bad_sequence):
    with pytest.raises(ValueError):
        featurize_target(bad_sequence)
