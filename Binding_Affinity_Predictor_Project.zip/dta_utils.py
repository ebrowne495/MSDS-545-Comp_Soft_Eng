"""Shared, deterministic drug/target features and inference utilities."""
from functools import lru_cache
import numpy as np
import joblib
from rdkit import Chem
from rdkit.Chem import rdFingerprintGenerator

AMINO_ACIDS = 'ACDEFGHIKLMNPQRSTVWY'
FINGERPRINT_BITS = 2048
FINGERPRINT_RADIUS = 2
_morgan = rdFingerprintGenerator.GetMorganGenerator(radius=FINGERPRINT_RADIUS, fpSize=FINGERPRINT_BITS)

@lru_cache(maxsize=2048)
def featurize_drug(smiles):
    """Return RDKit Morgan fingerprint; fail clearly for invalid SMILES."""
    if not isinstance(smiles, str) or not smiles.strip():
        raise ValueError('Enter a non-empty drug SMILES string.')
    mol = Chem.MolFromSmiles(smiles.strip())
    if mol is None:
        raise ValueError('Invalid SMILES string. Please check the molecular structure.')
    return np.asarray(_morgan.GetFingerprintAsNumPy(mol), dtype=np.float32)

@lru_cache(maxsize=1024)
def featurize_target(sequence):
    """20 amino-acid fractions, ordered alphabetically by AMINO_ACIDS."""
    if not isinstance(sequence, str):
        raise ValueError('Protein sequence must be text.')
    seq = ''.join(sequence.upper().split())
    if not seq or any(aa not in AMINO_ACIDS for aa in seq):
        raise ValueError('Protein sequence must contain only the 20 standard amino acids.')
    return np.asarray([seq.count(aa)/len(seq) for aa in AMINO_ACIDS], dtype=np.float32)

def pair_features(smiles, sequence):
    return np.concatenate((featurize_drug(smiles), featurize_target(sequence)))

def load_model(path='davis_affinity_model.joblib'):
    bundle = joblib.load(path)
    if bundle.get('feature_count') != FINGERPRINT_BITS + len(AMINO_ACIDS):
        raise ValueError('Model feature dimensions do not match this app.')
    return bundle

def predict_affinity(smiles, sequence, model_bundle):
    features = pair_features(smiles, sequence).reshape(1, -1)
    return float(model_bundle['model'].predict(features)[0])
